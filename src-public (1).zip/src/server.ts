import index from "../public/index.html"

const srv = Bun.serve({
  port: 3000,
  routes: { "/": index },
})

console.log(`Server is running on ${srv.url}`)
